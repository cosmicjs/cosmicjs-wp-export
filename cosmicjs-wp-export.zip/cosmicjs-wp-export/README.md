##Cosmic JS WordPress Export Plugin
This plugin helps you export your posts from WordPress into a JSON file.  This file can then be uploaded into Cosmic JS.

## To export
1. Go to the plugins section in the backend of your WordPress install. 
2. Click Add new.
3. Click Upload Plugin.
4. Click choose file.  Chosse the cosmicjs-wp-export.zip file included in this repo.
5. Activate plugin.
6. Find a new link in your Settings section of your WP sidebar nav titled "Cosmic JS Export".  Click it.
7. Select the post types that you would like to export.
8. Submit.  This will download a JSON formatted file with your all of your WordPress posts and media.
9. Go to your Cosmic JS account at https://cosmicjs.com
10. Add a new bucket or select a current bucket (careful, this will overwrite all of your bucket's content and media).
11. Click the Import link in the Settings nav.
12. Upload the WordPress export JSON file. This will upload all of your posts that were selected as well as all upload all media from your WP site to your bucket on Cosmic JS.
13. Enjoy the freedom of content in the cloud.
